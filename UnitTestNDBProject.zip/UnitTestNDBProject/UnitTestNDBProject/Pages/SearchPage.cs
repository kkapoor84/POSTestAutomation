﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnitTestNDBProject.Utils;
using static UnitTestNDBProject.Pages.LoginPage;

namespace UnitTestNDBProject.Pages
{
    class SearchPage
    {
 

    }
}
