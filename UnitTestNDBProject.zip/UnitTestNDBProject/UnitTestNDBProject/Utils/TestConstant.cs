﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestNDBProject.Utils
{
    class TestConstant
    {
     
        public static String ValidUser = "pos-acctrec";
        public static String Validpwd = "N0tS3cur3!";
        public static String InvalidUser = "pos-acctrec!";

   

    }
}
